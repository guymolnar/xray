from db_manager import DatabaseManager
import os

def create_all_tables(db_manager):
    """
    Create all necessary tables for the application using DatabaseManager instance.
    
    Args:
        db_manager: An initialized DatabaseManager instance
    """
    db_manager.create_table(
        "clients",
        "(client_id INT PRIMARY KEY, client_ip VARCHAR(255), client_port INT, last_seen DATETIME, ddos_status BOOLEAN, total_sent_media INT, total_files_uploaded INT DEFAULT 0, files_with_hidden_data INT DEFAULT 0, total_files_decoded INT DEFAULT 0)"
    )
    
    db_manager.create_table(
        "decrypted_media",
        "(user_id VARCHAR(255), media_type_id INT, path_to_decrypted_media VARCHAR(255))"
    )
    
    db_manager.create_table(
        "media_menu",
        "(id_media INT PRIMARY KEY, image_path VARCHAR(255), audio_path VARCHAR(255), video_path VARCHAR(255))"
    )
    
    db_manager.create_table(
        "users",
        "(username VARCHAR(255) PRIMARY KEY, "
        "password_hash VARCHAR(100), "   # salted form: "<32-hex salt>$<64-hex sha256>" = 97 chars
        "user_id INT UNIQUE)"
    )
    
def ensure_clients_schema(db_manager):
    """
    Add newer columns to an already-existing `clients` table.

    DatabaseManager.create_table() skips tables that already exist, so a
    database created by an older version of the project would be missing the
    statistics columns. This brings it up to date without dropping data.

    Args:
        db_manager: An initialized DatabaseManager instance
    """
    cursor = db_manager.conn.cursor()
    cursor.execute("SHOW COLUMNS FROM clients")
    existing = {row[0] for row in cursor.fetchall()}

    columns = {
        "total_files_uploaded": "INT DEFAULT 0",
        "files_with_hidden_data": "INT DEFAULT 0",
        "total_files_decoded": "INT DEFAULT 0"
    }
    for name, definition in columns.items():
        if name not in existing:
            cursor.execute(f"ALTER TABLE clients ADD COLUMN {name} {definition}")
            print(f"clients: added column {name}")
    db_manager.conn.commit()

def populate_media_menu(db_manager):
    """
    Populate the media_menu table with predefined data if it's empty.
    
    Args:
        db_manager: An initialized DatabaseManager instance
    """
    predefined_media = [
        (1, "poke.jpg", None, None),
        (2, "logo_cyber.jpeg", None, None),
        (3, "mizperamon1.png", None, None),
    ]

    existing_rows = db_manager.get_all_rows("media_menu")
    if not existing_rows:
        for media in predefined_media:
            db_manager.insert_row(
                "media_menu",
                "(id_media, image_path, audio_path, video_path)",
                "(%s, %s, %s, %s)",
                media
            )
def repair_media_paths(db_manager):
    """Rewrite any absolute / machine-specific media path to a bare filename."""
    for id_media, img, aud, vid in db_manager.get_all_rows("media_menu"):
        for col, val in (("image_path", img), ("audio_path", aud), ("video_path", vid)):
            if val and (os.path.isabs(val) or ":" in val or val.startswith("\\\\")):
                db_manager.update_row("media_menu", "id_media", id_media,
                                      [col], [os.path.basename(val)])